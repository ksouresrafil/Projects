/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Kian/Documents/CECS 460/Project2/BitCounter.v";
static int ng1[] = {11, 0};
static unsigned int ng2[] = {0U, 0U};
static unsigned int ng3[] = {1U, 0U};



static void Cont_26_0(char *t0)
{
    char t6[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;

LAB0:    t1 = (t0 + 3168U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(26, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t6, 0, 8);
    t7 = (t4 + 4);
    t8 = (t5 + 4);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    t22 = (t0 + 4096);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memset(t26, 0, 8);
    t27 = 1U;
    t28 = t27;
    t29 = (t6 + 4);
    t30 = *((unsigned int *)t6);
    t27 = (t27 & t30);
    t31 = *((unsigned int *)t29);
    t28 = (t28 & t31);
    t32 = (t26 + 4);
    t33 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t33 | t27);
    t34 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t34 | t28);
    xsi_driver_vfirst_trans(t22, 0, 0);
    t35 = (t0 + 3984);
    *((int *)t35) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

}

static void Always_28_1(char *t0)
{
    char t13[8];
    char t22[8];
    char t33[8];
    char t52[8];
    char t60[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    char *t42;
    char *t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    char *t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t59;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    char *t64;
    char *t65;
    char *t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    char *t74;
    char *t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    int t84;
    int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    char *t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    char *t98;
    char *t99;

LAB0:    t1 = (t0 + 3416U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(28, ng0);
    t2 = (t0 + 4000);
    *((int *)t2) = 1;
    t3 = (t0 + 3448);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(29, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB5;

LAB6:    xsi_set_current_line(31, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB11;

LAB9:    if (*((unsigned int *)t2) == 0)
        goto LAB8;

LAB10:    t4 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t4) = 1;

LAB11:    t5 = (t13 + 4);
    t11 = (t3 + 4);
    t14 = *((unsigned int *)t3);
    t15 = (~(t14));
    *((unsigned int *)t13) = t15;
    *((unsigned int *)t5) = 0;
    if (*((unsigned int *)t11) != 0)
        goto LAB13;

LAB12:    t20 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t20 & 1U);
    t21 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t21 & 1U);
    memset(t22, 0, 8);
    t12 = (t13 + 4);
    t23 = *((unsigned int *)t12);
    t24 = (~(t23));
    t25 = *((unsigned int *)t13);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t12) != 0)
        goto LAB16;

LAB17:    t29 = (t22 + 4);
    t30 = *((unsigned int *)t22);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB18;

LAB19:    memcpy(t60, t22, 8);

LAB20:    t92 = (t60 + 4);
    t93 = *((unsigned int *)t92);
    t94 = (~(t93));
    t95 = *((unsigned int *)t60);
    t96 = (t95 & t94);
    t97 = (t96 != 0);
    if (t97 > 0)
        goto LAB34;

LAB35:    xsi_set_current_line(33, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB40;

LAB38:    if (*((unsigned int *)t2) == 0)
        goto LAB37;

LAB39:    t4 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t4) = 1;

LAB40:    t5 = (t13 + 4);
    t11 = (t3 + 4);
    t14 = *((unsigned int *)t3);
    t15 = (~(t14));
    *((unsigned int *)t13) = t15;
    *((unsigned int *)t5) = 0;
    if (*((unsigned int *)t11) != 0)
        goto LAB42;

LAB41:    t20 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t20 & 1U);
    t21 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t21 & 1U);
    memset(t22, 0, 8);
    t12 = (t13 + 4);
    t23 = *((unsigned int *)t12);
    t24 = (~(t23));
    t25 = *((unsigned int *)t13);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB43;

LAB44:    if (*((unsigned int *)t12) != 0)
        goto LAB45;

LAB46:    t29 = (t22 + 4);
    t30 = *((unsigned int *)t22);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB47;

LAB48:    memcpy(t52, t22, 8);

LAB49:    t65 = (t52 + 4);
    t77 = *((unsigned int *)t65);
    t78 = (~(t77));
    t79 = *((unsigned int *)t52);
    t80 = (t79 & t78);
    t81 = (t80 != 0);
    if (t81 > 0)
        goto LAB57;

LAB58:    xsi_set_current_line(35, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB60;

LAB61:    if (*((unsigned int *)t2) != 0)
        goto LAB62;

LAB63:    t5 = (t13 + 4);
    t14 = *((unsigned int *)t13);
    t15 = *((unsigned int *)t5);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB64;

LAB65:    memcpy(t52, t13, 8);

LAB66:    t65 = (t52 + 4);
    t77 = *((unsigned int *)t65);
    t78 = (~(t77));
    t79 = *((unsigned int *)t52);
    t80 = (t79 & t78);
    t81 = (t80 != 0);
    if (t81 > 0)
        goto LAB80;

LAB81:    xsi_set_current_line(37, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB83;

LAB84:    if (*((unsigned int *)t2) != 0)
        goto LAB85;

LAB86:    t5 = (t13 + 4);
    t14 = *((unsigned int *)t13);
    t15 = *((unsigned int *)t5);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB87;

LAB88:    memcpy(t33, t13, 8);

LAB89:    t43 = (t33 + 4);
    t57 = *((unsigned int *)t43);
    t58 = (~(t57));
    t61 = *((unsigned int *)t33);
    t62 = (t61 & t58);
    t63 = (t62 != 0);
    if (t63 > 0)
        goto LAB97;

LAB98:
LAB99:
LAB82:
LAB59:
LAB36:
LAB7:    goto LAB2;

LAB5:    xsi_set_current_line(30, ng0);
    t11 = ((char*)((ng2)));
    t12 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 4, 0LL);
    goto LAB7;

LAB8:    *((unsigned int *)t13) = 1;
    goto LAB11;

LAB13:    t16 = *((unsigned int *)t13);
    t17 = *((unsigned int *)t11);
    *((unsigned int *)t13) = (t16 | t17);
    t18 = *((unsigned int *)t5);
    t19 = *((unsigned int *)t11);
    *((unsigned int *)t5) = (t18 | t19);
    goto LAB12;

LAB14:    *((unsigned int *)t22) = 1;
    goto LAB17;

LAB16:    t28 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB17;

LAB18:    t34 = (t0 + 1528U);
    t35 = *((char **)t34);
    memset(t33, 0, 8);
    t34 = (t35 + 4);
    t36 = *((unsigned int *)t34);
    t37 = (~(t36));
    t38 = *((unsigned int *)t35);
    t39 = (t38 & t37);
    t40 = (t39 & 1U);
    if (t40 != 0)
        goto LAB24;

LAB22:    if (*((unsigned int *)t34) == 0)
        goto LAB21;

LAB23:    t41 = (t33 + 4);
    *((unsigned int *)t33) = 1;
    *((unsigned int *)t41) = 1;

LAB24:    t42 = (t33 + 4);
    t43 = (t35 + 4);
    t44 = *((unsigned int *)t35);
    t45 = (~(t44));
    *((unsigned int *)t33) = t45;
    *((unsigned int *)t42) = 0;
    if (*((unsigned int *)t43) != 0)
        goto LAB26;

LAB25:    t50 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t50 & 1U);
    t51 = *((unsigned int *)t42);
    *((unsigned int *)t42) = (t51 & 1U);
    memset(t52, 0, 8);
    t53 = (t33 + 4);
    t54 = *((unsigned int *)t53);
    t55 = (~(t54));
    t56 = *((unsigned int *)t33);
    t57 = (t56 & t55);
    t58 = (t57 & 1U);
    if (t58 != 0)
        goto LAB27;

LAB28:    if (*((unsigned int *)t53) != 0)
        goto LAB29;

LAB30:    t61 = *((unsigned int *)t22);
    t62 = *((unsigned int *)t52);
    t63 = (t61 & t62);
    *((unsigned int *)t60) = t63;
    t64 = (t22 + 4);
    t65 = (t52 + 4);
    t66 = (t60 + 4);
    t67 = *((unsigned int *)t64);
    t68 = *((unsigned int *)t65);
    t69 = (t67 | t68);
    *((unsigned int *)t66) = t69;
    t70 = *((unsigned int *)t66);
    t71 = (t70 != 0);
    if (t71 == 1)
        goto LAB31;

LAB32:
LAB33:    goto LAB20;

LAB21:    *((unsigned int *)t33) = 1;
    goto LAB24;

LAB26:    t46 = *((unsigned int *)t33);
    t47 = *((unsigned int *)t43);
    *((unsigned int *)t33) = (t46 | t47);
    t48 = *((unsigned int *)t42);
    t49 = *((unsigned int *)t43);
    *((unsigned int *)t42) = (t48 | t49);
    goto LAB25;

LAB27:    *((unsigned int *)t52) = 1;
    goto LAB30;

LAB29:    t59 = (t52 + 4);
    *((unsigned int *)t52) = 1;
    *((unsigned int *)t59) = 1;
    goto LAB30;

LAB31:    t72 = *((unsigned int *)t60);
    t73 = *((unsigned int *)t66);
    *((unsigned int *)t60) = (t72 | t73);
    t74 = (t22 + 4);
    t75 = (t52 + 4);
    t76 = *((unsigned int *)t22);
    t77 = (~(t76));
    t78 = *((unsigned int *)t74);
    t79 = (~(t78));
    t80 = *((unsigned int *)t52);
    t81 = (~(t80));
    t82 = *((unsigned int *)t75);
    t83 = (~(t82));
    t84 = (t77 & t79);
    t85 = (t81 & t83);
    t86 = (~(t84));
    t87 = (~(t85));
    t88 = *((unsigned int *)t66);
    *((unsigned int *)t66) = (t88 & t86);
    t89 = *((unsigned int *)t66);
    *((unsigned int *)t66) = (t89 & t87);
    t90 = *((unsigned int *)t60);
    *((unsigned int *)t60) = (t90 & t86);
    t91 = *((unsigned int *)t60);
    *((unsigned int *)t60) = (t91 & t87);
    goto LAB33;

LAB34:    xsi_set_current_line(32, ng0);
    t98 = ((char*)((ng2)));
    t99 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t99, t98, 0, 0, 4, 0LL);
    goto LAB36;

LAB37:    *((unsigned int *)t13) = 1;
    goto LAB40;

LAB42:    t16 = *((unsigned int *)t13);
    t17 = *((unsigned int *)t11);
    *((unsigned int *)t13) = (t16 | t17);
    t18 = *((unsigned int *)t5);
    t19 = *((unsigned int *)t11);
    *((unsigned int *)t5) = (t18 | t19);
    goto LAB41;

LAB43:    *((unsigned int *)t22) = 1;
    goto LAB46;

LAB45:    t28 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB46;

LAB47:    t34 = (t0 + 1528U);
    t35 = *((char **)t34);
    memset(t33, 0, 8);
    t34 = (t35 + 4);
    t36 = *((unsigned int *)t34);
    t37 = (~(t36));
    t38 = *((unsigned int *)t35);
    t39 = (t38 & t37);
    t40 = (t39 & 1U);
    if (t40 != 0)
        goto LAB50;

LAB51:    if (*((unsigned int *)t34) != 0)
        goto LAB52;

LAB53:    t44 = *((unsigned int *)t22);
    t45 = *((unsigned int *)t33);
    t46 = (t44 & t45);
    *((unsigned int *)t52) = t46;
    t42 = (t22 + 4);
    t43 = (t33 + 4);
    t53 = (t52 + 4);
    t47 = *((unsigned int *)t42);
    t48 = *((unsigned int *)t43);
    t49 = (t47 | t48);
    *((unsigned int *)t53) = t49;
    t50 = *((unsigned int *)t53);
    t51 = (t50 != 0);
    if (t51 == 1)
        goto LAB54;

LAB55:
LAB56:    goto LAB49;

LAB50:    *((unsigned int *)t33) = 1;
    goto LAB53;

LAB52:    t41 = (t33 + 4);
    *((unsigned int *)t33) = 1;
    *((unsigned int *)t41) = 1;
    goto LAB53;

LAB54:    t54 = *((unsigned int *)t52);
    t55 = *((unsigned int *)t53);
    *((unsigned int *)t52) = (t54 | t55);
    t59 = (t22 + 4);
    t64 = (t33 + 4);
    t56 = *((unsigned int *)t22);
    t57 = (~(t56));
    t58 = *((unsigned int *)t59);
    t61 = (~(t58));
    t62 = *((unsigned int *)t33);
    t63 = (~(t62));
    t67 = *((unsigned int *)t64);
    t68 = (~(t67));
    t84 = (t57 & t61);
    t85 = (t63 & t68);
    t69 = (~(t84));
    t70 = (~(t85));
    t71 = *((unsigned int *)t53);
    *((unsigned int *)t53) = (t71 & t69);
    t72 = *((unsigned int *)t53);
    *((unsigned int *)t53) = (t72 & t70);
    t73 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t73 & t69);
    t76 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t76 & t70);
    goto LAB56;

LAB57:    xsi_set_current_line(34, ng0);
    t66 = ((char*)((ng2)));
    t74 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t74, t66, 0, 0, 4, 0LL);
    goto LAB59;

LAB60:    *((unsigned int *)t13) = 1;
    goto LAB63;

LAB62:    t4 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t4) = 1;
    goto LAB63;

LAB64:    t11 = (t0 + 1528U);
    t12 = *((char **)t11);
    memset(t22, 0, 8);
    t11 = (t12 + 4);
    t17 = *((unsigned int *)t11);
    t18 = (~(t17));
    t19 = *((unsigned int *)t12);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB70;

LAB68:    if (*((unsigned int *)t11) == 0)
        goto LAB67;

LAB69:    t28 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t28) = 1;

LAB70:    t29 = (t22 + 4);
    t34 = (t12 + 4);
    t23 = *((unsigned int *)t12);
    t24 = (~(t23));
    *((unsigned int *)t22) = t24;
    *((unsigned int *)t29) = 0;
    if (*((unsigned int *)t34) != 0)
        goto LAB72;

LAB71:    t31 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t31 & 1U);
    t32 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t32 & 1U);
    memset(t33, 0, 8);
    t35 = (t22 + 4);
    t36 = *((unsigned int *)t35);
    t37 = (~(t36));
    t38 = *((unsigned int *)t22);
    t39 = (t38 & t37);
    t40 = (t39 & 1U);
    if (t40 != 0)
        goto LAB73;

LAB74:    if (*((unsigned int *)t35) != 0)
        goto LAB75;

LAB76:    t44 = *((unsigned int *)t13);
    t45 = *((unsigned int *)t33);
    t46 = (t44 & t45);
    *((unsigned int *)t52) = t46;
    t42 = (t13 + 4);
    t43 = (t33 + 4);
    t53 = (t52 + 4);
    t47 = *((unsigned int *)t42);
    t48 = *((unsigned int *)t43);
    t49 = (t47 | t48);
    *((unsigned int *)t53) = t49;
    t50 = *((unsigned int *)t53);
    t51 = (t50 != 0);
    if (t51 == 1)
        goto LAB77;

LAB78:
LAB79:    goto LAB66;

LAB67:    *((unsigned int *)t22) = 1;
    goto LAB70;

LAB72:    t25 = *((unsigned int *)t22);
    t26 = *((unsigned int *)t34);
    *((unsigned int *)t22) = (t25 | t26);
    t27 = *((unsigned int *)t29);
    t30 = *((unsigned int *)t34);
    *((unsigned int *)t29) = (t27 | t30);
    goto LAB71;

LAB73:    *((unsigned int *)t33) = 1;
    goto LAB76;

LAB75:    t41 = (t33 + 4);
    *((unsigned int *)t33) = 1;
    *((unsigned int *)t41) = 1;
    goto LAB76;

LAB77:    t54 = *((unsigned int *)t52);
    t55 = *((unsigned int *)t53);
    *((unsigned int *)t52) = (t54 | t55);
    t59 = (t13 + 4);
    t64 = (t33 + 4);
    t56 = *((unsigned int *)t13);
    t57 = (~(t56));
    t58 = *((unsigned int *)t59);
    t61 = (~(t58));
    t62 = *((unsigned int *)t33);
    t63 = (~(t62));
    t67 = *((unsigned int *)t64);
    t68 = (~(t67));
    t84 = (t57 & t61);
    t85 = (t63 & t68);
    t69 = (~(t84));
    t70 = (~(t85));
    t71 = *((unsigned int *)t53);
    *((unsigned int *)t53) = (t71 & t69);
    t72 = *((unsigned int *)t53);
    *((unsigned int *)t53) = (t72 & t70);
    t73 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t73 & t69);
    t76 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t76 & t70);
    goto LAB79;

LAB80:    xsi_set_current_line(36, ng0);
    t66 = (t0 + 2248);
    t74 = (t66 + 56U);
    t75 = *((char **)t74);
    t92 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t92, t75, 0, 0, 4, 0LL);
    goto LAB82;

LAB83:    *((unsigned int *)t13) = 1;
    goto LAB86;

LAB85:    t4 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t4) = 1;
    goto LAB86;

LAB87:    t11 = (t0 + 1528U);
    t12 = *((char **)t11);
    memset(t22, 0, 8);
    t11 = (t12 + 4);
    t17 = *((unsigned int *)t11);
    t18 = (~(t17));
    t19 = *((unsigned int *)t12);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB90;

LAB91:    if (*((unsigned int *)t11) != 0)
        goto LAB92;

LAB93:    t23 = *((unsigned int *)t13);
    t24 = *((unsigned int *)t22);
    t25 = (t23 & t24);
    *((unsigned int *)t33) = t25;
    t29 = (t13 + 4);
    t34 = (t22 + 4);
    t35 = (t33 + 4);
    t26 = *((unsigned int *)t29);
    t27 = *((unsigned int *)t34);
    t30 = (t26 | t27);
    *((unsigned int *)t35) = t30;
    t31 = *((unsigned int *)t35);
    t32 = (t31 != 0);
    if (t32 == 1)
        goto LAB94;

LAB95:
LAB96:    goto LAB89;

LAB90:    *((unsigned int *)t22) = 1;
    goto LAB93;

LAB92:    t28 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB93;

LAB94:    t36 = *((unsigned int *)t33);
    t37 = *((unsigned int *)t35);
    *((unsigned int *)t33) = (t36 | t37);
    t41 = (t13 + 4);
    t42 = (t22 + 4);
    t38 = *((unsigned int *)t13);
    t39 = (~(t38));
    t40 = *((unsigned int *)t41);
    t44 = (~(t40));
    t45 = *((unsigned int *)t22);
    t46 = (~(t45));
    t47 = *((unsigned int *)t42);
    t48 = (~(t47));
    t84 = (t39 & t44);
    t85 = (t46 & t48);
    t49 = (~(t84));
    t50 = (~(t85));
    t51 = *((unsigned int *)t35);
    *((unsigned int *)t35) = (t51 & t49);
    t54 = *((unsigned int *)t35);
    *((unsigned int *)t35) = (t54 & t50);
    t55 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t55 & t49);
    t56 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t56 & t50);
    goto LAB96;

LAB97:    xsi_set_current_line(38, ng0);
    t53 = (t0 + 2248);
    t59 = (t53 + 56U);
    t64 = *((char **)t59);
    t65 = ((char*)((ng3)));
    memset(t52, 0, 8);
    xsi_vlog_unsigned_add(t52, 4, t64, 4, t65, 4);
    t66 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t66, t52, 0, 0, 4, 0LL);
    goto LAB99;

}

static void Always_40_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;

LAB0:    t1 = (t0 + 3664U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 4016);
    *((int *)t2) = 1;
    t3 = (t0 + 3696);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(41, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB5;

LAB6:    xsi_set_current_line(44, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 2088);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 0LL);

LAB7:    goto LAB2;

LAB5:    xsi_set_current_line(42, ng0);
    t11 = ((char*)((ng2)));
    t12 = (t0 + 2088);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 1, 0LL);
    goto LAB7;

}


extern void work_m_00000000001680496249_3326385499_init()
{
	static char *pe[] = {(void *)Cont_26_0,(void *)Always_28_1,(void *)Always_40_2};
	xsi_register_didat("work_m_00000000001680496249_3326385499", "isim/tx_tf_isim_beh.exe.sim/work/m_00000000001680496249_3326385499.didat");
	xsi_register_executes(pe);
}
