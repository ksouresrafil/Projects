/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Kian/Documents/CECS 460/Project2/Data_Decoder.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {3U, 0U};
static unsigned int ng3[] = {1U, 0U};
static unsigned int ng4[] = {2U, 0U};
static unsigned int ng5[] = {4U, 0U};
static unsigned int ng6[] = {5U, 0U};
static unsigned int ng7[] = {6U, 0U};
static unsigned int ng8[] = {7U, 0U};



static void Always_24_0(char *t0)
{
    char t4[8];
    char t12[8];
    char t13[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int t9;
    char *t10;
    char *t11;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;

LAB0:    t1 = (t0 + 3168U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(24, ng0);
    t2 = (t0 + 3984);
    *((int *)t2) = 1;
    t3 = (t0 + 3200);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(25, ng0);

LAB5:    xsi_set_current_line(26, ng0);
    t5 = (t0 + 1368U);
    t6 = *((char **)t5);
    t5 = (t0 + 1208U);
    t7 = *((char **)t5);
    t5 = (t0 + 1528U);
    t8 = *((char **)t5);
    xsi_vlogtype_concat(t4, 3, 3, 3U, t8, 1, t7, 1, t6, 1);

LAB6:    t5 = ((char*)((ng1)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t5, 3);
    if (t9 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng3)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng4)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng2)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng5)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng6)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng7)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng8)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB21;

LAB22:
LAB24:
LAB23:    xsi_set_current_line(35, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2248);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 2);

LAB25:    goto LAB2;

LAB7:    xsi_set_current_line(27, ng0);
    t10 = ((char*)((ng2)));
    t11 = (t0 + 2248);
    xsi_vlogvar_assign_value(t11, t10, 0, 0, 2);
    goto LAB25;

LAB9:    xsi_set_current_line(28, ng0);
    t3 = ((char*)((ng2)));
    t5 = (t0 + 2248);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 2);
    goto LAB25;

LAB11:    xsi_set_current_line(29, ng0);
    t3 = (t0 + 1688U);
    t5 = *((char **)t3);
    t3 = ((char*)((ng3)));
    xsi_vlogtype_concat(t12, 2, 2, 2U, t3, 1, t5, 1);
    t6 = (t0 + 2248);
    xsi_vlogvar_assign_value(t6, t12, 0, 0, 2);
    goto LAB25;

LAB13:    xsi_set_current_line(30, ng0);
    t3 = (t0 + 1848U);
    t5 = *((char **)t3);
    t3 = ((char*)((ng3)));
    xsi_vlogtype_concat(t12, 2, 2, 2U, t3, 1, t5, 1);
    t6 = (t0 + 2248);
    xsi_vlogvar_assign_value(t6, t12, 0, 0, 2);
    goto LAB25;

LAB15:    xsi_set_current_line(31, ng0);
    t3 = (t0 + 1048U);
    t5 = *((char **)t3);
    memset(t13, 0, 8);
    t3 = (t13 + 4);
    t6 = (t5 + 4);
    t14 = *((unsigned int *)t5);
    t15 = (t14 >> 7);
    t16 = (t15 & 1);
    *((unsigned int *)t13) = t16;
    t17 = *((unsigned int *)t6);
    t18 = (t17 >> 7);
    t19 = (t18 & 1);
    *((unsigned int *)t3) = t19;
    t7 = ((char*)((ng3)));
    xsi_vlogtype_concat(t12, 2, 2, 2U, t7, 1, t13, 1);
    t8 = (t0 + 2248);
    xsi_vlogvar_assign_value(t8, t12, 0, 0, 2);
    goto LAB25;

LAB17:    xsi_set_current_line(32, ng0);
    t3 = (t0 + 1048U);
    t5 = *((char **)t3);
    memset(t13, 0, 8);
    t3 = (t13 + 4);
    t6 = (t5 + 4);
    t14 = *((unsigned int *)t5);
    t15 = (t14 >> 7);
    t16 = (t15 & 1);
    *((unsigned int *)t13) = t16;
    t17 = *((unsigned int *)t6);
    t18 = (t17 >> 7);
    t19 = (t18 & 1);
    *((unsigned int *)t3) = t19;
    t7 = ((char*)((ng3)));
    xsi_vlogtype_concat(t12, 2, 2, 2U, t7, 1, t13, 1);
    t8 = (t0 + 2248);
    xsi_vlogvar_assign_value(t8, t12, 0, 0, 2);
    goto LAB25;

LAB19:    xsi_set_current_line(33, ng0);
    t3 = (t0 + 1048U);
    t5 = *((char **)t3);
    memset(t13, 0, 8);
    t3 = (t13 + 4);
    t6 = (t5 + 4);
    t14 = *((unsigned int *)t5);
    t15 = (t14 >> 7);
    t16 = (t15 & 1);
    *((unsigned int *)t13) = t16;
    t17 = *((unsigned int *)t6);
    t18 = (t17 >> 7);
    t19 = (t18 & 1);
    *((unsigned int *)t3) = t19;
    t7 = (t0 + 1688U);
    t8 = *((char **)t7);
    xsi_vlogtype_concat(t12, 2, 2, 2U, t8, 1, t13, 1);
    t7 = (t0 + 2248);
    xsi_vlogvar_assign_value(t7, t12, 0, 0, 2);
    goto LAB25;

LAB21:    xsi_set_current_line(34, ng0);
    t3 = (t0 + 1048U);
    t5 = *((char **)t3);
    memset(t13, 0, 8);
    t3 = (t13 + 4);
    t6 = (t5 + 4);
    t14 = *((unsigned int *)t5);
    t15 = (t14 >> 7);
    t16 = (t15 & 1);
    *((unsigned int *)t13) = t16;
    t17 = *((unsigned int *)t6);
    t18 = (t17 >> 7);
    t19 = (t18 & 1);
    *((unsigned int *)t3) = t19;
    t7 = (t0 + 1848U);
    t8 = *((char **)t7);
    xsi_vlogtype_concat(t12, 2, 2, 2U, t8, 1, t13, 1);
    t7 = (t0 + 2248);
    xsi_vlogvar_assign_value(t7, t12, 0, 0, 2);
    goto LAB25;

}

static void Cont_39_1(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 3416U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 1048U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t4 + 4);
    t5 = *((unsigned int *)t4);
    t6 = *((unsigned int *)t4);
    t6 = (t6 & 1);
    if (*((unsigned int *)t2) != 0)
        goto LAB4;

LAB5:    t8 = 1;

LAB7:    t9 = (t8 <= 7);
    if (t9 == 1)
        goto LAB8;

LAB9:    *((unsigned int *)t3) = t6;

LAB6:    t11 = (t0 + 4096);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memset(t15, 0, 8);
    t16 = 1U;
    t17 = t16;
    t18 = (t3 + 4);
    t19 = *((unsigned int *)t3);
    t16 = (t16 & t19);
    t20 = *((unsigned int *)t18);
    t17 = (t17 & t20);
    t21 = (t15 + 4);
    t22 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t22 | t16);
    t23 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t23 | t17);
    xsi_driver_vfirst_trans(t11, 0, 0);
    t24 = (t0 + 4000);
    *((int *)t24) = 1;

LAB1:    return;
LAB4:    t7 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB6;

LAB8:    t5 = (t5 >> 1);
    t10 = (t5 & 1);
    t6 = (t6 ^ t10);

LAB10:    t8 = (t8 + 1);
    goto LAB7;

}

static void Cont_40_2(char *t0)
{
    char t3[8];
    char t4[8];
    char *t1;
    char *t2;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    char *t42;

LAB0:    t1 = (t0 + 3664U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 1048U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t5);
    t7 = *((unsigned int *)t5);
    t7 = (t7 & 1);
    if (*((unsigned int *)t2) != 0)
        goto LAB4;

LAB5:    t9 = 1;

LAB7:    t10 = (t9 <= 7);
    if (t10 == 1)
        goto LAB8;

LAB9:    *((unsigned int *)t4) = t7;

LAB6:    memset(t3, 0, 8);
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t4);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB14;

LAB12:    if (*((unsigned int *)t12) == 0)
        goto LAB11;

LAB13:    t18 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t18) = 1;

LAB14:    t19 = (t3 + 4);
    t20 = (t4 + 4);
    t21 = *((unsigned int *)t4);
    t22 = (~(t21));
    *((unsigned int *)t3) = t22;
    *((unsigned int *)t19) = 0;
    if (*((unsigned int *)t20) != 0)
        goto LAB16;

LAB15:    t27 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t27 & 1U);
    t28 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t28 & 1U);
    t29 = (t0 + 4160);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    memset(t33, 0, 8);
    t34 = 1U;
    t35 = t34;
    t36 = (t3 + 4);
    t37 = *((unsigned int *)t3);
    t34 = (t34 & t37);
    t38 = *((unsigned int *)t36);
    t35 = (t35 & t38);
    t39 = (t33 + 4);
    t40 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t40 | t34);
    t41 = *((unsigned int *)t39);
    *((unsigned int *)t39) = (t41 | t35);
    xsi_driver_vfirst_trans(t29, 0, 0);
    t42 = (t0 + 4016);
    *((int *)t42) = 1;

LAB1:    return;
LAB4:    t8 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB6;

LAB8:    t6 = (t6 >> 1);
    t11 = (t6 & 1);
    t7 = (t7 ^ t11);

LAB10:    t9 = (t9 + 1);
    goto LAB7;

LAB11:    *((unsigned int *)t3) = 1;
    goto LAB14;

LAB16:    t23 = *((unsigned int *)t3);
    t24 = *((unsigned int *)t20);
    *((unsigned int *)t3) = (t23 | t24);
    t25 = *((unsigned int *)t19);
    t26 = *((unsigned int *)t20);
    *((unsigned int *)t19) = (t25 | t26);
    goto LAB15;

}


extern void work_m_00000000002762347682_0595333340_init()
{
	static char *pe[] = {(void *)Always_24_0,(void *)Cont_39_1,(void *)Cont_40_2};
	xsi_register_didat("work_m_00000000002762347682_0595333340", "isim/tx_tf_isim_beh.exe.sim/work/m_00000000002762347682_0595333340.didat");
	xsi_register_executes(pe);
}
